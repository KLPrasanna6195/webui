from rest_framework.decorators import api_view
from django.shortcuts import render
from rest_framework.response import Response
from rest_framework import status
from search.models import searchModel


@api_view(['get'])
def get_queryset(request):
    if request.method == "GET":
        query = request.GET.get('NAME')
        if query:
            match = searchModel.objects.filter(name__icontains=query).values('name').order_by('name')
            results = list(match)
            if results == []:
                return Response('no results found based on search word', status=status.HTTP_200_OK)
            else:
                return Response(match[:21], status=status.HTTP_200_OK)
        else:
            return render(request, 'search.html')

